-- client/client.lua
-- Lathios Invoice (Rework) - Fase 2
-- NPC + Blip + Interacción (Target / TextUI) + NUI (abrir/cerrar/refresh/pagar)

local RES = GetCurrentResourceName()

local nuiOpen = false
local npcPed = nil
local blip = nil
local showingTextUI = false
local lastInteractAt = 0

local function dprint(...)
  if Config and Config.Debug then
    print('^3[LBI]^7', ...)
  end
end

local function nowMs()
  return GetGameTimer()
end

local function antiSpamOk()
  local cd = 0
  if Config and Config.Security and Config.Security.AntiSpamSeconds then
    cd = tonumber(Config.Security.AntiSpamSeconds) or 0
  end
  if cd <= 0 then return true end
  local n = nowMs()
  if (n - lastInteractAt) < (cd * 1000) then
    local left = math.ceil(((cd * 1000) - (n - lastInteractAt)) / 1000)
    Bridge.Notify(L('err_cooldown', 'Espera {seconds}s antes de intentar nuevamente.', { seconds = left }), 'error')
    return false
  end
  lastInteractAt = n
  return true
end

-- =========================================================
-- NUI helpers
-- =========================================================

local function setNui(open, mode, receipt)
  nuiOpen = open and true or false
  SetNuiFocus(nuiOpen, nuiOpen)
  SetNuiFocusKeepInput(nuiOpen)

  SendNUIMessage({
    action = nuiOpen and 'open' or 'close',
    mode = mode or 'pay',
    receipt = receipt,
    locale = (Config and Config.Locale) or 'en',
    currency = { symbol = '$', right = false },
    tiers = {
      standard = L('tier_standard', 'Standard'),
      premium = L('tier_premium', 'Premium'),
      vip = L('tier_vip', 'VIP'),
    },
    labels = {
      title = L('nui_title', 'Pago de Impuestos'),
      subtitle = L('nui_subtitle', 'Selecciona un negocio y realiza el pago correspondiente'),
      business = L('nui_business', 'Negocio'),
      due = L('nui_due', 'Total a pagar'),
      next_due = L('nui_next_due', 'Próximo cobro'),
      tier = L('nui_tier', 'Tier'),
      fees = L('nui_fees', 'Desglose'),
      pay = L('nui_pay', 'Pagar'),
      close = L('nui_close', 'Cerrar'),
      status_ok = L('nui_status_ok', 'Al día'),
      status_due = L('nui_status_due', 'Con deuda'),
      debt_accumulated = L('nui_debt_accumulated', 'Deuda acumulada'),
      total = L('nui_total', 'Total'),
    },
    receiptLabels = {
      title = L('receipt_title', 'Boleta de pago'),
      subtitle = L('receipt_subtitle', 'Comprobante del impuesto pagado'),
      label_id = L('receipt_label_id', 'Boleta'),
      label_business = L('receipt_label_business', 'Negocio'),
      label_payer = L('receipt_label_payer', 'Pagó'),
      label_date = L('receipt_label_date', 'Fecha'),
      label_method = L('receipt_label_method', 'Método'),
      label_total = L('receipt_label_total', 'Total'),
      label_breakdown = L('receipt_label_breakdown', 'Detalle'),
      close = L('receipt_close', 'Cerrar'),
    }
  })
end

local function closeUI()
  if not nuiOpen then return end
  setNui(false)
end

-- NOTE: En Fase 2 NO abrimos la NUI “a ciegas”.
-- Pedimos al servidor los negocios “pagables ahora” y sólo si viene >=1, abrimos.
local function requestOpenPayUI()
  if not antiSpamOk() then return end
  -- Nuevo flujo (rework)
  TriggerServerEvent('lbi:server:ui:requestPayables')
  -- Back-compat (server antiguo) para poder testear Fase 2 sin esperar la Fase 3
  TriggerServerEvent('lbi:server:requestStatus', 'all')
end

RegisterNUICallback('close', function(_, cb)
  closeUI()
  cb({ ok = true })
end)

RegisterNUICallback('refresh', function(_, cb)
  TriggerServerEvent('lbi:server:ui:requestPayables')
  TriggerServerEvent('lbi:server:requestStatus', 'all')
  cb({ ok = true })
end)

RegisterNUICallback('pay', function(data, cb)
  local businessId = data and data.businessId
  if not businessId or businessId == '' then
    cb({ ok = false, error = 'missing_business' })
    return
  end
  TriggerServerEvent('lbi:server:ui:pay', businessId)
  TriggerServerEvent('lbi:server:payBusiness', businessId) -- back-compat
  cb({ ok = true })
end)

-- Bloquea controles mientras NUI está abierta (evita bindeos en el teclado)
CreateThread(function()
  while true do
    if nuiOpen then
      DisableAllControlActions(0)
      EnableControlAction(0, 241, true) -- SCROLL UP
      EnableControlAction(0, 242, true) -- SCROLL DOWN
      Wait(0)
    else
      Wait(250)
    end
  end
end)

-- Respuesta del servidor: lista filtrada de negocios pagables ahora
RegisterNetEvent('lbi:client:ui:payables', function(ok, payload, errKey)
  if not ok then
    Bridge.Notify(L(errKey or 'err_unknown', 'Error'), 'error')
    return
  end

  local businesses = (payload and payload.businesses) or {}
  if type(businesses) ~= 'table' then businesses = {} end

  if #businesses <= 0 then
    -- Importante: tu decisión fue “solo abrir si hay al menos 1 pagable”
    Bridge.Notify(L('err_no_payables_now', 'Aún no hay facturas habilitadas para pagar.'), 'inform')
    return
  end

  -- Abrir NUI y empujar data
  if not nuiOpen then
    setNui(true, 'pay')
  end

  SendNUIMessage({
    action = 'setBusinesses',
    data = { businesses = businesses }
  })
end)

-- Confirmación de pago (servidor)
RegisterNetEvent('lbi:client:ui:paid', function(ok, msgKey, msgVars)
  if not ok then
    Bridge.Notify(L(msgKey or 'err_unknown', 'Pago fallido', msgVars), 'error')
    return
  end
  Bridge.Notify(L(msgKey or 'ok_paid', 'Pago realizado.', msgVars), 'success')
  closeUI()
end)

-- ================================
-- Back-compat (server antiguo)
-- ================================

local function openWithBusinesses(businesses)
  if type(businesses) ~= 'table' then businesses = {} end
  if #businesses <= 0 then
    Bridge.Notify(L('err_no_payables_now', 'Aún no hay facturas habilitadas para pagar.'), 'inform')
    return
  end
  if not nuiOpen then
    setNui(true, 'pay')
  end
  SendNUIMessage({ action = 'setBusinesses', data = { businesses = businesses } })
end

-- El server antiguo responde con 'lbi:client:statusResponse'. Aquí filtramos localmente
-- para mantener tu regla: SOLO mostrar negocios pagables ahora.
RegisterNetEvent('lbi:client:statusResponse', function(ok, data, errMsg)
  if not ok then
    if errMsg and errMsg ~= '' then
      Bridge.Notify(errMsg, 'error')
    end
    return
  end
  if not data or not data.businesses then return end

  local filtered = {}
  for _, b in ipairs(data.businesses) do
    local payWindow = (b.pay_window_open == true)
    local can = (b.can_pay_cycle == true) or (b.can_pay_debt == true)
    if payWindow or can then
      filtered[#filtered+1] = {
        id = b.id,
        label = b.label or b.id,
        tier = b.tier or 'standard',
        tier_multiplier = tonumber(b.tier_multiplier) or 1.0,
        balance = tonumber(b.balance) or 0,
        next_due_at = tonumber(b.next_due_at) or 0,
        cycle_amount = tonumber(b.statement_cycle_amount or b.cycle_amount) or 0,
        breakdown = b.statement_breakdown or b.breakdown or {},
        total_due = tonumber(b.statement_total_due or b.total_due) or ((tonumber(b.balance) or 0) + (tonumber(b.statement_cycle_amount or b.cycle_amount) or 0)),
      }
    end
  end

  openWithBusinesses(filtered)
end)

RegisterNetEvent('lbi:client:payResponse', function(ok, data, errMsg)
  if not ok then
    Bridge.Notify(errMsg or 'Pago fallido', 'error')
    return
  end
  Bridge.Notify(L('ok_paid', 'Pago realizado: {amount}. ¡Gracias!', { amount = tostring(data and data.paid or '') }), 'success')
  closeUI()
end)

-- Abrir boleta desde item usable
RegisterNetEvent('lbi:client:openReceipt', function(receipt)
  setNui(true, 'receipt', receipt)
end)

-- =========================================================
-- NPC + Blip
-- =========================================================

local function loadModel(model)
  local hash = type(model) == 'number' and model or joaat(model)
  if not IsModelInCdimage(hash) then return nil end
  RequestModel(hash)
  local t = GetGameTimer()
  while not HasModelLoaded(hash) do
    Wait(25)
    if GetGameTimer() - t > 7000 then break end
  end
  if not HasModelLoaded(hash) then return nil end
  return hash
end

local function ensureBlip(coords)
  if not (Config and Config.Blip and Config.Blip.enabled) then return end
  if blip and DoesBlipExist(blip) then return end

  blip = AddBlipForCoord(coords.x, coords.y, coords.z)
  SetBlipSprite(blip, Config.Blip.sprite or 525)
  SetBlipScale(blip, Config.Blip.scale or 0.8)
  SetBlipColour(blip, Config.Blip.color or 3)
  SetBlipAsShortRange(blip, true)
  BeginTextCommandSetBlipName('STRING')
  AddTextComponentString(Config.Blip.label or 'Impuestos')
  EndTextCommandSetBlipName(blip)
end

local function createNPC()
  if not (Config and Config.NPC and Config.NPC.enabled) then return end
  if npcPed and DoesEntityExist(npcPed) then return end

  local cfg = Config.NPC
  local hash = loadModel(cfg.model)
  if not hash then
    print('^1[LBI]^7 NPC model inválido:', cfg.model)
    return
  end

  local c = cfg.coords
  local spawnZ = c.z
  RequestCollisionAtCoord(c.x, c.y, c.z)
  local found, groundZ = GetGroundZFor_3dCoord(c.x, c.y, c.z + 2.0, false)
  if found and groundZ and groundZ > 0.0 then
    spawnZ = groundZ
  end

  npcPed = CreatePed(0, hash, c.x, c.y, spawnZ, c.w or 0.0, false, true)
  SetModelAsNoLongerNeeded(hash)

  SetEntityAsMissionEntity(npcPed, true, true)
  SetEntityInvincible(npcPed, cfg.invincible ~= false)
  SetEntityCanBeDamaged(npcPed, false)
  SetBlockingOfNonTemporaryEvents(npcPed, cfg.blockEvents ~= false)
  FreezeEntityPosition(npcPed, cfg.frozen ~= false)

  SetPedCanRagdoll(npcPed, false)
  SetPedDiesWhenInjured(npcPed, false)
  SetPedFleeAttributes(npcPed, 0, false)
  SetPedCombatAttributes(npcPed, 46, true) -- no flee
  SetPedSeeingRange(npcPed, 0.0)
  SetPedHearingRange(npcPed, 0.0)
  SetPedAlertness(npcPed, 0)
  SetPedDropsWeaponsWhenDead(npcPed, false)

  if cfg.scenario and cfg.scenario ~= '' then
    TaskStartScenarioInPlace(npcPed, cfg.scenario, 0, true)
  end

  ensureBlip(c)
  dprint('NPC creado:', npcPed)
end

local function destroyNPC()
  if blip and DoesBlipExist(blip) then
    RemoveBlip(blip)
  end
  blip = nil

  if npcPed and DoesEntityExist(npcPed) then
    DeleteEntity(npcPed)
  end
  npcPed = nil
end

-- =========================================================
-- Interacción
-- =========================================================

local function showOxTextUI(msg)
  if (lib and lib.showTextUI) then
    lib.showTextUI(msg, { position = 'left-center' })
    return true
  end
  if GetResourceState('ox_lib') == 'started' and exports.ox_lib and exports.ox_lib.showTextUI then
    exports.ox_lib:showTextUI(msg, { position = 'left-center' })
    return true
  end
  return false
end

local function hideOxTextUI()
  if (lib and lib.hideTextUI) then
    lib.hideTextUI()
    return true
  end
  if GetResourceState('ox_lib') == 'started' and exports.ox_lib and exports.ox_lib.hideTextUI then
    exports.ox_lib:hideTextUI()
    return true
  end
  return false
end

local function textUiMessage()
  return L('interact_textui', '[E] Pagar impuestos del negocio')
end

local function showTextUI()
  local msg = textUiMessage()
  if showingTextUI then return end
  showingTextUI = true

  -- Prefer ox_lib
  if showOxTextUI(msg) then return end

  -- Fallback help notification
  CreateThread(function()
    while showingTextUI and not nuiOpen do
      BeginTextCommandDisplayHelp('STRING')
      AddTextComponentSubstringPlayerName(msg)
      EndTextCommandDisplayHelp(0, false, false, 1)
      Wait(0)
    end
  end)
end

local function hideTextUI()
  if not showingTextUI then return end
  showingTextUI = false
  hideOxTextUI()
end

local function startTextUiLoop()
  CreateThread(function()
    local distMax = 2.0
    local key = 38 -- E
    while GetResourceState(RES) == 'started' do
      if npcPed and DoesEntityExist(npcPed) and not nuiOpen then
        local p = PlayerPedId()
        local pc = GetEntityCoords(p)
        local nc = GetEntityCoords(npcPed)
        local dist = #(pc - nc)

        if dist <= distMax then
          showTextUI()
          if IsControlJustPressed(0, key) then
            requestOpenPayUI()
            hideTextUI()
          end
          Wait(0)
        else
          hideTextUI()
          Wait(250)
        end
      else
        hideTextUI()
        Wait(500)
      end
    end
  end)
end

local function addTargetInteraction()
  if not (Config and Config.Target) then
    return false
  end
  if not npcPed or not DoesEntityExist(npcPed) then
    return false
  end

  local label = L('interact_target_label', 'Pagar impuestos del negocio')
  local icon = (Config.TargetIcons and (Config.TargetIcons.managmenticon or Config.TargetIcons.ticketicon)) or 'fa-solid fa-file-invoice-dollar'
  local distance = 2.0

  local t = tostring(Config.Targettype or 'oxtarget'):lower()
  if t == 'oxtarget' and GetResourceState('ox_target') == 'started' then
    exports.ox_target:addLocalEntity(npcPed, {
      {
        name = 'lbi_pay',
        label = label,
        icon = icon,
        distance = distance,
        onSelect = function()
          requestOpenPayUI()
        end,
      }
    })
    return true
  end

  if t == 'qbtarget' and GetResourceState('qb-target') == 'started' then
    exports['qb-target']:AddTargetEntity(npcPed, {
      options = {
        {
          type = 'client',
          event = 'lbi:client:interact',
          icon = icon,
          label = label,
        }
      },
      distance = distance,
    })
    return true
  end

  if t == 'qtarget' and GetResourceState('qtarget') == 'started' then
    exports['qtarget']:AddTargetEntity(npcPed, {
      options = {
        {
          event = 'lbi:client:interact',
          icon = icon,
          label = label,
        }
      },
      distance = distance,
    })
    return true
  end

  return false
end

RegisterNetEvent('lbi:client:interact', function()
  requestOpenPayUI()
end)

-- =========================================================
-- Test commands (cliente) -> ejecutan lógica en servidor (seguro)
-- =========================================================

local function registerTestCommands()
  if not (Config and Config.TestMode) then return end

  RegisterCommand('lbi_test_due', function(_, args)
    local businessId = args[1]
    local seconds = tonumber(args[2] or '')
    if not businessId or businessId == '' or not seconds then
      Bridge.Notify('Uso: /lbi_test_due <businessId> <seconds>', 'error')
      return
    end
    TriggerServerEvent('lbi:server:test:due', businessId, seconds)
  end, false)

  RegisterCommand('lbi_test_reminder', function(_, args)
    local businessId = args[1]
    if not businessId or businessId == '' then
      Bridge.Notify('Uso: /lbi_test_reminder <businessId>', 'error')
      return
    end
    TriggerServerEvent('lbi:server:test:reminder', businessId)
  end, false)

  RegisterCommand('lbi_test_overdue', function(_, args)
    local businessId = args[1]
    local periods = tonumber(args[2] or '1') or 1
    if not businessId or businessId == '' then
      Bridge.Notify('Uso: /lbi_test_overdue <businessId> [periods]', 'error')
      return
    end
    TriggerServerEvent('lbi:server:test:overdue', businessId, periods)
  end, false)

  RegisterCommand('lbi_test_pay', function(_, args)
    local businessId = args[1]
    if not businessId or businessId == '' then
      Bridge.Notify('Uso: /lbi_test_pay <businessId>', 'error')
      return
    end
    TriggerServerEvent('lbi:server:test:pay', businessId)
  end, false)

  Bridge.Notify('TestMode ON: /lbi_test_due | /lbi_test_reminder | /lbi_test_overdue | /lbi_test_pay', 'inform')
end

RegisterNetEvent('lbi:client:test:result', function(ok, msg)
  Bridge.Notify(msg or (ok and 'OK' or 'ERROR'), ok and 'success' or 'error')
end)

-- =========================================================
-- Lifecycle
-- =========================================================

AddEventHandler('onResourceStart', function(res)
  if res ~= RES then return end
  Wait(250)

  pcall(function()
    if Bridge and Bridge.Init then Bridge.Init() end
  end)

  createNPC()

  -- Prefer target; fallback a TextUI
  local okTarget = addTargetInteraction()
  if not okTarget then
    startTextUiLoop()
  end

  registerTestCommands()
end)

AddEventHandler('onResourceStop', function(res)
  if res ~= RES then return end
  hideTextUI()
  destroyNPC()
  if nuiOpen then
    SetNuiFocus(false, false)
    nuiOpen = false
  end
end)
