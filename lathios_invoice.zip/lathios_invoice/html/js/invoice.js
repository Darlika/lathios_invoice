// html/js/invoice.js
// Lathios_Business_Invoices - NUI

let resourceName = (typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'lathios_invoice';
let businesses = [];
let selectedId = null;

let labels = {};
let receiptLabels = {};
let uiMode = 'pay';
let receiptData = null;
let currency = { symbol: '$', right: false };
let locale = 'en';
let tierLabels = {};

const el = (id) => document.getElementById(id);

function fmtMoney(amount) {
  if (amount == null) return '-';
  const n = Number(amount);
  if (!Number.isFinite(n)) return '-';
  const sym = currency.symbol || '$';
  if (currency.right) return `${n}${sym}`;
  return `${sym}${n}`;
}

function pad2(n) { return String(n).padStart(2, '0'); }

function fmtDate(ts) {
  ts = Number(ts || 0);
  if (!ts || ts <= 0) return '-';
  const d = new Date(ts * 1000);

  const dd = pad2(d.getDate());
  const mm = pad2(d.getMonth() + 1);
  const yyyy = d.getFullYear();
  const hh = pad2(d.getHours());
  const mi = pad2(d.getMinutes());
  const ss = pad2(d.getSeconds());

  if ((locale || 'en') === 'es') {
    return `${dd}/${mm}/${yyyy} ${hh}:${mi}:${ss}`;
  }
  // default en
  return `${mm}/${dd}/${yyyy} ${hh}:${mi}:${ss}`;
}

// Backwards-compatible helpers (older code referenced these)
function formatDateTime(ts) { return fmtDate(ts); }
function formatCurrency(amount) { return fmtMoney(amount); }

function getTotalDue(b) {
  const bal = Number(b.balance || 0);
  const cycle = Number(b.cycle_amount || 0);
  if (b.total_due != null) return Number(b.total_due || 0);
  return bal + cycle;
}

function showApp(show) {
  const app = el('app');
  if (!app) return;
  app.classList.toggle('hidden', !show);
}

function setText(id, value) {
  const node = el(id);
  if (node) node.textContent = value;
}

function renderBusinessList() {
  const sel = el('businessSelect');
  if (!sel) return;

  sel.innerHTML = '';
  businesses.forEach((b) => {
    const opt = document.createElement('option');
    opt.value = b.id;
    opt.textContent = b.label || b.id;
    sel.appendChild(opt);
  });

  if (!selectedId && businesses.length > 0) selectedId = businesses[0].id;
  if (selectedId) sel.value = selectedId;
}

function renderBusinessDetails() {
  const b = businesses.find(x => x.id === selectedId);

  if (!b) {
    setText('dueValue', '-');
    setText('nextDueValue', '-');
    setText('tierValue', '-');
    const feesList = el('feesList');
    if (feesList) feesList.innerHTML = '';
    return;
  }

  const totalDue = getTotalDue(b);
  setText('dueValue', fmtMoney(totalDue));
  setText('nextDueValue', fmtDate(b.next_due_at));
  setText('tierValue', tierLabels[b.tier] || b.tier || '-');

  // Breakdown
  const list = el('feesList');
  if (!list) return;
  list.innerHTML = '';

  const rows = [];
  const bal = Number(b.balance || 0);
  if (bal > 0) {
    rows.push({ label: labels.debt_accumulated || 'Deuda acumulada', amount: bal, isTotal: false });
  }

  if (Array.isArray(b.breakdown)) {
    b.breakdown.forEach((fee) => {
      const a = Number(fee.amount || 0);
      if (!a || a <= 0) return;
      rows.push({ label: fee.label || fee.key || '-', amount: a, isTotal: false });
    });
  }

  rows.push({ label: labels.total || 'Total', amount: totalDue, isTotal: true });

  rows.forEach((r) => {
    const div = document.createElement('div');
    div.className = 'feeRow' + (r.isTotal ? ' total' : '');
    div.innerHTML = `<div class="feeLabel">${r.label}</div><div class="feeAmount">${fmtMoney(r.amount)}</div>`;
    list.appendChild(div);
  });

  // Pay button enabled when there's something to pay
  const btnPay = el('btnPay');
  if (btnPay) {
    btnPay.disabled = totalDue <= 0;
  }
}

function applyLabels() {
  setText('title', labels.title || 'Pago de Impuestos');
  setText('subtitle', labels.subtitle || '');
  setText('btnClose', labels.close || 'Cerrar');
  setText('lblBusiness', labels.business || 'Negocio');
  setText('lblDue', labels.due || 'Total');
  setText('lblNextDue', labels.next_due || 'Próximo cobro');
  setText('lblTier', labels.tier || 'Tier');
  setText('lblFees', labels.fees || 'Desglose');
  setText('btnPay', labels.pay || 'Pagar');
}

function showMode(mode) {
  uiMode = mode || 'pay';
  const payView = el('payView');
  const receiptView = el('receiptView');
  if (payView) payView.style.display = (uiMode === 'pay') ? 'block' : 'none';
  if (receiptView) receiptView.style.display = (uiMode === 'receipt') ? 'block' : 'none';

  // Hide header close + subtitle on receipt view (only keep the bottom close)
  const headerClose = el('btnClose');
  const headerSubtitle = el('subtitle');
  if (uiMode === 'receipt') {
    if (headerClose) headerClose.style.display = 'none';
    if (headerSubtitle) headerSubtitle.style.display = 'none';
  } else {
    if (headerClose) headerClose.style.display = '';
    if (headerSubtitle) headerSubtitle.style.display = '';
  }
}

function applyReceiptLabels() {
  // titles
  if (receiptLabels.title) el('receiptTitle').textContent = receiptLabels.title;
  if (receiptLabels.subtitle) el('receiptSubtitle').textContent = receiptLabels.subtitle;
  // section labels
  el('rLabelId').textContent = receiptLabels.label_id || 'Boleta';
  el('rLabelBusiness').textContent = receiptLabels.label_business || 'Negocio';
  el('rLabelPayer').textContent = receiptLabels.label_payer || 'Pagó';
  el('rLabelDate').textContent = receiptLabels.label_date || 'Fecha';
  el('rLabelMethod').textContent = receiptLabels.label_method || 'Método';
  el('rLabelTotal').textContent = receiptLabels.label_total || 'Total';
  el('receiptBreakdownTitle').textContent = receiptLabels.label_breakdown || 'Detalle';
  if (receiptLabels.close) el('btnReceiptClose').textContent = receiptLabels.close;
}

function renderReceipt(data) {
  receiptData = data || null;
  if (!receiptData) return;

  el('rValueId').textContent = receiptData.id != null ? `#${receiptData.id}` : '-';
  el('rValueBusiness').textContent = receiptData.business_label || receiptData.business_id || '-';
  el('rValuePayer').textContent = receiptData.payer_name || receiptData.payer_identifier || '-';

  // Fecha
  el('rValueDate').textContent = fmtDate(receiptData.paid_at || receiptData.paidAt || 0);

  // Método
  el('rValueMethod').textContent = receiptData.method_label || receiptData.method || '-';

  // Total (fallbacks)
  const meta = receiptData.meta || {};
  const total =
    (receiptData.total != null ? receiptData.total : null) ??
    (receiptData.amount != null ? receiptData.amount : null) ??
    (meta.total != null ? meta.total : null) ??
    (meta.total_amount != null ? meta.total_amount : null) ??
    null;

  el('rValueTotal').textContent = formatCurrency(total);

  const listEl = el('receiptBreakdownList');
  if (listEl) listEl.innerHTML = '';

  // Build rows from meta (be tolerant to different shapes)
  const rows = [];

  const debtPaid = Number(meta.debt_paid || meta.debtPaid || 0);
  if (debtPaid > 0) {
    rows.push({ label: (receiptLabels.debt_accumulated || labels.debt_accumulated || 'Deuda acumulada'), amount: debtPaid });
  }

  const breakdown = Array.isArray(meta.breakdown) ? meta.breakdown
    : (Array.isArray(receiptData.breakdown) ? receiptData.breakdown : []);

  if (Array.isArray(breakdown)) {
    breakdown.forEach((b) => {
      const label = b.label || b.key || '-';
      let amount = null;

      if (b.amount != null) amount = b.amount;
      else if (b.value != null) amount = b.value;
      else if (b.cents != null) amount = Number(b.cents) / 100;

      amount = Number(amount || 0);
      if (!amount || amount <= 0) return;

      rows.push({ label, amount });
    });
  }

  if (listEl) {
    if (rows.length) {
      rows.forEach((r) => {
        const row = document.createElement('div');
        row.className = 'receiptRow';
        const label = document.createElement('div');
        label.className = 'receiptRowLabel';
        label.textContent = r.label || '-';
        const val = document.createElement('div');
        val.className = 'receiptRowValue';
        val.textContent = formatCurrency(r.amount);
        row.appendChild(label);
        row.appendChild(val);
        listEl.appendChild(row);
      });
    } else {
      const row = document.createElement('div');
      row.className = 'receiptRow';
      const label = document.createElement('div');
      label.className = 'receiptRowLabel';
      label.textContent = '-';
      const val = document.createElement('div');
      val.className = 'receiptRowValue';
      val.textContent = '-';
      row.appendChild(label);
      row.appendChild(val);
      listEl.appendChild(row);
    }
  }
}

async function nuiFetch(name, data = {}) {
  const url = `https://${resourceName}/${name}`;
  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json; charset=UTF-8' },
      body: JSON.stringify(data)
    });

    // Some Lua callbacks return empty strings or non-JSON; be tolerant.
    const text = await res.text();
    if (!text) return {};
    try {
      return JSON.parse(text);
    } catch (e) {
      return {};
    }
  } catch (err) {
    console.error('[lathios_invoice][nuiFetch] failed', name, err);
    return {};
  }
}
// UI events
window.addEventListener('message', (event) => {
  const msg = event.data || {};

  if (msg.action === 'open') {
    if (msg.resource) resourceName = msg.resource;
    showApp(true);

    locale = msg.locale || locale;
    tierLabels = msg.tiers || tierLabels;

    labels = msg.labels || labels;
    receiptLabels = msg.receiptLabels || receiptLabels;
    uiMode = msg.mode || uiMode;
    receiptData = msg.receipt || receiptData;
    // allow title/subtitle in same payload
    if (msg.title) labels.title = msg.title;
    if (msg.subtitle) labels.subtitle = msg.subtitle;

    currency = msg.currency || currency;
    applyLabels();
    applyReceiptLabels();
    showMode(uiMode);
    if (uiMode === 'receipt' && receiptData) {
      renderReceipt(receiptData);
    }
    return;
  }

  if (msg.action === 'close') {
    showApp(false);
    return;
  }

  if (msg.action === 'setBusinesses') {
    const list = msg.businesses || (msg.data && msg.data.businesses) || [];
    businesses = Array.isArray(list) ? list : [];
    renderBusinessList();
    renderBusinessDetails();
    return;
  }
});

// DOM bindings
window.addEventListener('DOMContentLoaded', () => {
  const btnClose = el('btnClose');
  if (btnClose) btnClose.addEventListener('click', () => nuiFetch('close'));

  const btnReceiptClose = el('btnReceiptClose');
  if (btnReceiptClose) btnReceiptClose.addEventListener('click', () => nuiFetch('close'));

  const btnRefresh = el('btnRefresh');
  if (btnRefresh) btnRefresh.addEventListener('click', () => nuiFetch('refresh'));

  const businessSelect = el('businessSelect');
  if (businessSelect) {
    businessSelect.addEventListener('change', (e) => {
      selectedId = e.target.value;
      renderBusinessDetails();
    });
  }

  const btnPay = el('btnPay');
  if (btnPay) {
    btnPay.addEventListener('click', async () => {
      if (!selectedId) return;
      const btn = el('btnPay');
      if (btn) btn.disabled = true;

      try {
        await nuiFetch('pay', { businessId: selectedId });
      } finally {
        // Cerrar automáticamente al clicar pagar
        await nuiFetch('close');
        if (btn) btn.disabled = false;
      }
    });
  }

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      nuiFetch('close');
    }
  });
});
