Instalación ESX
1) Editar config.lua
2) Establecer Framework
3) Establecer lenguage ES
5) Verificar labels en que no se encuentran en language.lua tales como en config.lua y business.lua
6) Instalar item lathios_tax en tu inventario, la imagen del mismo se encuentra en la carpeta html (mas abajo se encuentran las diferentes líneas de inventarios)
7) Si gustas establece true en el Testmode

Instalación QBCORE
1) Editar config.lua
2) Establecer Framework
3) Establecer lenguage ES
4) Verificar labels en que no se encuentran en language.lua tales como en config.lua y business.lua
5) Instalar item lathios_tax en tu inventario, la imagen del mismo se encuentra en la carpeta html
6) Si gustas establece true en el Testmode
7) Verificar los permisos admin en .gfr (add_principal identifier.fivem:TU_LICENSE_AQUI group.admin)

Podrás probar el script estableciendo TestMode = true en el config.lua Además podrás utilizar los siguientes comando

/lbi_test_due <businessId> <seconds> ✅ fuerza vencimiento rápido
/lbi_test_reminder <businessId> ✅ dispara recordatorio
/lbi_test_overdue <businessId> [periods] ✅ simula mora y suma deuda
/lbi_test_pay <businessId> ✅ simula pago (admin)

<businessId> hace referencia al tipo de business de business.lua
<seconds> tiempo en segundo para el próximo vencimiento
[periods] cantidad de perioddos de deuda morosa




['lathios_tax']  = {['name'] = 'lathios_tax', ['label'] = 'Factura de Impuestos', ['weight'] = 0, ['type'] = 'item', ['image'] = 'lathios_tax.png', ['unique'] = false, ['useable'] = true, ['shouldClose'] = true, ['combinable'] = nil, ['description'] = 'Factura que demuestra los impuestos pagados'},