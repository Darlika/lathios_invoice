-- server/server.lua
-- Lathios Invoice (Rework) - Fase 3
-- Core server: estado SQL, scheduler, pagos, boletas (item), webhooks, modo test

local RES = GetCurrentResourceName()

local RECEIPT_ITEM = 'lathios_tax'
local RECEIPT_META_KEY = 'lbi_receipt_id'

local function dprint(...)
  if Config and Config.Debug then
    print('^3[LBI]^7', ...)
  end
end

local function now()
  return os.time()
end

-- =========================================================
-- Time windows (48h/24h in prod, seconds in test)
-- =========================================================

local function reminder48Seconds()
  if Config and Config.TestMode and Config.Test and Config.Test.ReminderSecondsBefore then
    return math.max(5, tonumber(Config.Test.ReminderSecondsBefore) or 20)
  end
  return 48 * 3600
end

local function reminder24Seconds()
  if Config and Config.TestMode and Config.Test and Config.Test.ReminderSecondsBefore then
    local v = math.floor((tonumber(Config.Test.ReminderSecondsBefore) or 20) / 2)
    return math.max(1, v)
  end
  return 24 * 3600
end

local function payWindowSeconds()
  -- Pago habilitado en la misma ventana del primer recordatorio (48h en prod / segundos en test)
  return reminder48Seconds()
end

local function schedulerTickSeconds()
  if Config and Config.TestMode and Config.Test and Config.Test.SchedulerTickSeconds then
    return math.max(1, tonumber(Config.Test.SchedulerTickSeconds) or 2)
  end
  if Config and Config.Scheduler and Config.Scheduler.TickSeconds then
    return math.max(1, tonumber(Config.Scheduler.TickSeconds) or 60)
  end
  return 60
end

-- =========================================================
-- Formatting
-- =========================================================

local function fmtMoney(amount)
  amount = tonumber(amount) or 0
  return ('$%s'):format(amount)
end

local function fmtDateTime(ts)
  ts = tonumber(ts) or now()
  if Config and Config.Locale == 'es' then
    return os.date('%d/%m/%Y %H:%M:%S', ts)
  end
  return os.date('%m/%d/%Y %H:%M:%S', ts)
end

-- =========================================================
-- Business / Fees / Tiers
-- =========================================================

local function getBusiness(businessId)
  return Config and Config.Businesses and Config.Businesses[businessId] or nil
end

local function getTierMultiplier(biz)
  local tier = (biz and biz.tier) or 'standard'
  local m = Config and Config.TierMultipliers and Config.TierMultipliers[tier]
  return tonumber(m) or 1.0
end

local function feeLabel(feeKey)
  return (Config and Config.FeeCatalog and Config.FeeCatalog[feeKey] and Config.FeeCatalog[feeKey].label) or tostring(feeKey)
end

local function buildFeeMapForBusiness(businessId)
  local biz = getBusiness(businessId)
  if not biz then return nil, 'err_unknown_business' end

  local typeCfg = Config and Config.Types and biz.type and Config.Types[biz.type] or nil
  local fees = {}

  if typeCfg and typeCfg.fees then
    for k, v in pairs(typeCfg.fees) do
      fees[k] = tonumber(v) or 0
    end
  end

  if biz.feeOverrides then
    for k, v in pairs(biz.feeOverrides) do
      fees[k] = tonumber(v) or 0
    end
  end

  return fees, nil
end

local function computeCycleAmountAndBreakdown(businessId)
  local biz = getBusiness(businessId)
  if not biz then return 0, {}, 'err_unknown_business' end

  local fees, errKey = buildFeeMapForBusiness(businessId)
  if errKey then return 0, {}, errKey end

  local mult = getTierMultiplier(biz)
  local breakdown, total = {}, 0

  for feeKey, baseAmount in pairs(fees) do
    baseAmount = tonumber(baseAmount) or 0
    if baseAmount > 0 then
      local final = math.floor((baseAmount * mult) + 0.5)
      total = total + final
      breakdown[#breakdown+1] = {
        key = feeKey,
        label = feeLabel(feeKey),
        amount = final,
        amount_base = baseAmount
      }
    end
  end

  table.sort(breakdown, function(a, b)
    return tostring(a.label) < tostring(b.label)
  end)

  return math.floor(total + 0.5), breakdown, nil
end

-- =========================================================
-- Billing math (daily / weekday / monthly)
-- =========================================================

local weekdayIndex = {
  sunday = 0, monday = 1, tuesday = 2, wednesday = 3, thursday = 4, friday = 5, saturday = 6,
}

local function normBilling(billing)
  billing = billing or {}
  local b = {}
  b.mode = tostring(billing.mode or 'weekday'):lower()
  b.day = billing.day
  b.hour = billing.hour
  b.minute = billing.minute

  if b.hour == nil then b.hour = 0 end
  if b.minute == nil then b.minute = 0 end

  return b
end

local function clampMonthlyTimestamp(year, month, day, hour, minute)
  day = tonumber(day) or 1
  hour = tonumber(hour) or 0
  minute = tonumber(minute) or 0

  local lastDay = os.date('*t', os.time({ year = year, month = month + 1, day = 0, hour = 12, min = 0, sec = 0 })).day
  local targetDay = math.min(math.max(1, day), lastDay)

  return os.time({ year = year, month = month, day = targetDay, hour = hour, min = minute, sec = 0 })
end

local function computeNextDueAt(billing, fromTs)
  local b = normBilling(billing)
  local base = tonumber(fromTs) or now()
  local t = os.date('*t', base)

  if b.mode == 'daily' then
    local candidate = os.time({ year = t.year, month = t.month, day = t.day, hour = b.hour, min = b.minute, sec = 0 })
    if candidate <= base then
      candidate = candidate + 86400
    end
    return candidate
  end

  if b.mode == 'monthly' then
    local targetDay = tonumber(b.day) or 1
    local candidate = clampMonthlyTimestamp(t.year, t.month, targetDay, b.hour, b.minute)
    if candidate <= base then
      local nextMonthTs = os.time({ year = t.year, month = t.month + 1, day = 1, hour = 12, min = 0, sec = 0 })
      local nt = os.date('*t', nextMonthTs)
      candidate = clampMonthlyTimestamp(nt.year, nt.month, targetDay, b.hour, b.minute)
    end
    return candidate
  end

  local target = weekdayIndex[tostring(b.day or 'monday'):lower()] or 1
  local current = (t.wday or 2) - 1
  local delta = target - current
  if delta < 0 then delta = delta + 7 end

  local candidate = os.time({ year = t.year, month = t.month, day = t.day, hour = b.hour, min = b.minute, sec = 0 }) + (delta * 86400)
  if candidate <= base then
    candidate = candidate + (7 * 86400)
  end
  return candidate
end

local function advanceDueAt(currentDueAt, billing, periods)
  local b = normBilling(billing)
  local p = tonumber(periods) or 1
  if p <= 0 then return tonumber(currentDueAt) or now() end

  local due = tonumber(currentDueAt) or now()

  if b.mode == 'daily' then
    return due + (86400 * p)
  end

  if b.mode == 'monthly' then
    local targetDay = tonumber(b.day) or 1
    for _ = 1, p do
      local t = os.date('*t', due)
      local nextMonthTs = os.time({ year = t.year, month = t.month + 1, day = 1, hour = 12, min = 0, sec = 0 })
      local nt = os.date('*t', nextMonthTs)
      due = clampMonthlyTimestamp(nt.year, nt.month, targetDay, b.hour, b.minute)
    end
    return due
  end

  return due + ((7 * 86400) * p)
end

-- =========================================================
-- Database helpers
-- =========================================================

local function dbGetState(businessId)
  local rows = MySQL.query.await('SELECT * FROM lbi_business_state WHERE business_id = ? LIMIT 1', { businessId }) or {}
  return rows[1]
end

local function dbInsertState(businessId, nextDueAt)
  MySQL.insert.await([[    INSERT IGNORE INTO lbi_business_state (business_id, next_due_at, balance)
    VALUES (?, ?, 0)
  ]], { businessId, tonumber(nextDueAt) or now() })
end

local function dbSaveStateRow(businessId, row)
  MySQL.update.await([[    UPDATE lbi_business_state
    SET next_due_at = ?,
        balance = ?,
        last_paid_at = ?,
        last_paid_by = ?,
        last_paid_by_name = ?,
        last_paid_method = ?,
        reminder_sent_for_due_at = ?,
        overdue_notified_for_due_at = ?
    WHERE business_id = ?
  ]], {
    tonumber(row.next_due_at) or now(),
    tonumber(row.balance) or 0,
    row.last_paid_at,
    row.last_paid_by,
    row.last_paid_by_name,
    row.last_paid_method,
    row.reminder_sent_for_due_at,
    row.overdue_notified_for_due_at,
    businessId
  })
end

local function ensureStateRow(businessId)
  local row = dbGetState(businessId)
  if row then return row end

  local biz = getBusiness(businessId)
  if not biz then return nil end

  local due
  if Config and Config.TestMode and Config.Test and Config.Test.ForceDueInSeconds then
    due = now() + (tonumber(Config.Test.ForceDueInSeconds) or 60)
  else
    due = computeNextDueAt(biz.billing, now())
  end

  dbInsertState(businessId, due)
  return dbGetState(businessId)
end

-- Catch-up de mora (no manda webhooks aquí; el scheduler decide)
local function catchUpBusiness(businessId, row)
  row = row or ensureStateRow(businessId)
  if not row then return nil, 0, 0, nil, 0 end

  local biz = getBusiness(businessId)
  if not biz then return row, 0, 0, nil, tonumber(row.overdue_notified_for_due_at) or 0 end

  local cycleAmount = select(1, computeCycleAmountAndBreakdown(businessId))
  local tsNow = now()

  local missed, addedTotal = 0, 0
  local lastMissedDueAt = nil
  local prevOverdueNotified = tonumber(row.overdue_notified_for_due_at) or 0

  local nextDue = tonumber(row.next_due_at) or computeNextDueAt(biz.billing, tsNow)

  while tsNow >= nextDue do
    missed = missed + 1
    lastMissedDueAt = nextDue
    addedTotal = addedTotal + cycleAmount
    row.balance = (tonumber(row.balance) or 0) + cycleAmount
    nextDue = advanceDueAt(nextDue, biz.billing, 1)

    row.reminder_sent_for_due_at = nil

    if missed >= 64 then
      dprint('catchUp cap reached for', businessId, 'missed=', missed)
      break
    end
  end

  if missed > 0 then
    row.next_due_at = nextDue
    dbSaveStateRow(businessId, row)
  end

  return row, missed, addedTotal, lastMissedDueAt, prevOverdueNotified
end

-- =========================================================
-- Webhooks (Discord)
-- =========================================================

local function shouldSendWebhooks()
  if Config and Config.Webhooks == false then return false end
  return true
end

local function discordPost(url, payload)
  if not url or url == '' then return end
  if not shouldSendWebhooks() then return end

  if Config and Config.TestMode and Config.Test and Config.Test.DryRunWebhooks then
    dprint('[DryRunWebhook]', url, json.encode(payload))
    return
  end

  PerformHttpRequest(url, function(errCode, _, _)
    if errCode and errCode >= 400 then
      dprint('Webhook error', errCode, url)
    end
  end, 'POST', json.encode(payload), { ['Content-Type'] = 'application/json' })
end

local function sendWebhookSimple(url, titleKey, descKey, vars, color)
  if not url or url == '' then return end
  local title = L(titleKey, titleKey, vars)
  local desc = L(descKey, descKey, vars)
  local embed = {
    title = title,
    description = desc,
    color = color or 3447003,
    footer = { text = 'LBI' }
  }
  discordPost(url, { embeds = { embed } })
end

local function makeItemsLines(debtPaid, breakdown)
  local lines = {}

  if (tonumber(debtPaid) or 0) > 0 then
    lines[#lines+1] = ('• %s: %s'):format(L('nui_debt_accumulated', 'Accumulated debt'), fmtMoney(debtPaid))
  end

  if type(breakdown) == 'table' then
    for _, b in ipairs(breakdown) do
      local a = tonumber(b.amount) or 0
      if a > 0 then
        lines[#lines+1] = ('• %s: %s'):format(tostring(b.label or b.key), fmtMoney(a))
      end
    end
  end

  return table.concat(lines, '\n')
end

local function sendReminderWebhook(businessId, row, stageLabel)
  local biz = getBusiness(businessId)
  if not biz or not biz.webhooks or not biz.webhooks.reminder then return end

  local cycleAmount = select(1, computeCycleAmountAndBreakdown(businessId))
  local debt = tonumber(row.balance) or 0
  local total = debt + cycleAmount

  sendWebhookSimple(
    biz.webhooks.reminder,
    'wh_reminder_title',
    'wh_reminder_desc',
    {
      label = biz.label or businessId,
      due = fmtDateTime(row.next_due_at),
      debt = fmtMoney(debt),
      cycle = fmtMoney(cycleAmount),
      total = fmtMoney(total),
      stage = stageLabel or ''
    },
    16753920
  )
end

local function sendOverdueWebhook(businessId, row, lastMissedDueAt, addedTotal, missedPeriods)
  local biz = getBusiness(businessId)
  if not biz then return end
  local label = biz.label or businessId

  local debtNow = tonumber(row.balance) or 0
  local dueStr = fmtDateTime(lastMissedDueAt or row.next_due_at)

  if biz.webhooks and biz.webhooks.reminder then
    sendWebhookSimple(
      biz.webhooks.reminder,
      'wh_overdue_title',
      'wh_overdue_desc',
      { label = label, amount = fmtMoney(debtNow), due = dueStr, periods = missedPeriods or 1, added = fmtMoney(addedTotal or 0) },
      15158332
    )
  end

  if Config and Config.AdminWebhook and Config.AdminWebhook ~= '' then
    sendWebhookSimple(
      Config.AdminWebhook,
      'wh_overdue_title',
      'wh_overdue_desc',
      { label = label, amount = fmtMoney(debtNow), due = dueStr, periods = missedPeriods or 1, added = fmtMoney(addedTotal or 0) },
      15158332
    )
  end
end

local function sendPaymentWebhook(businessId, paymentAmount, payerName, payerIdentifier, method, kindKey, tierKey, nextDueAt, debtPaid, breakdown)
  local biz = getBusiness(businessId)
  if not biz then return end

  local tier = biz.tier or 'standard'
  local tierLabel = L('tier_' .. tier, tier)

  local items = makeItemsLines(debtPaid, breakdown)

  if biz.webhooks and biz.webhooks.payment then
    sendWebhookSimple(
      biz.webhooks.payment,
      'wh_payment_title',
      'wh_payment_desc',
      {
        label = biz.label or businessId,
        amount = fmtMoney(paymentAmount),
        payer = payerName or payerIdentifier or 'Unknown',
        date = fmtDateTime(now()),
        kind = L(kindKey or 'paykind_settle', 'Payment'),
        tier = tierLabel,
        next_due = fmtDateTime(nextDueAt),
        items = items
      },
      3066993
    )
  end

  if Config and Config.AdminWebhook and Config.AdminWebhook ~= '' then
    sendWebhookSimple(
      Config.AdminWebhook,
      'wh_admin_title',
      'wh_admin_desc',
      {
        label = biz.label or businessId,
        amount = fmtMoney(paymentAmount),
        payer = payerName or payerIdentifier or 'Unknown',
        date = fmtDateTime(now()),
        next_due = fmtDateTime(nextDueAt)
      },
      3066993
    )
  end
end

-- =========================================================
-- Security checks
-- =========================================================

local function isOwnerAllowed(src, biz)
  if not (Config and Config.Security and Config.Security.OwnerOnlyCanPay) then
    return true
  end
  local ids = biz and biz.owner and biz.owner.identifiers or nil
  return Bridge.MatchesOwner(src, ids)
end

local function nearNpcOk(src)
  if not (Config and Config.Security and Config.Security.RequireNearNPC) then
    return true
  end
  if not (Config and Config.NPC and Config.NPC.enabled and Config.NPC.coords) then
    return true
  end

  local ped = GetPlayerPed(src)
  if not ped or ped == 0 then return false end

  local p = GetEntityCoords(ped)
  local c = Config.NPC.coords
  local dx = (p.x - c.x)
  local dy = (p.y - c.y)
  local dz = (p.z - c.z)
  local dist = math.sqrt((dx*dx) + (dy*dy) + (dz*dz))
  return dist <= (tonumber(Config.Security.MaxDistanceToNPC) or 4.0)
end

local lastActionAt = {}
local function antiSpamServer(src)
  local cd = 0
  if Config and Config.Security and Config.Security.AntiSpamSeconds then
    cd = tonumber(Config.Security.AntiSpamSeconds) or 0
  end
  if cd <= 0 then return true end

  local ts = now()
  local prev = lastActionAt[src] or 0
  if (ts - prev) < cd then
    local left = cd - (ts - prev)
    Bridge.Notify(src, L('err_cooldown', 'Wait {seconds}s', { seconds = left }), 'error')
    return false
  end
  lastActionAt[src] = ts
  return true
end

-- =========================================================
-- Payables builder
-- =========================================================

local function buildPayableEntry(businessId, row, includeCycle, windowOpen)
  local biz = getBusiness(businessId)
  if not biz or not row then return nil end

  includeCycle = (includeCycle ~= false)
  local balance = tonumber(row.balance) or 0
  local cycleAmount, breakdown = 0, {}

  if includeCycle then
    cycleAmount, breakdown = computeCycleAmountAndBreakdown(businessId)
  end

  local total = balance + (tonumber(cycleAmount) or 0)

  return {
    id = businessId,
    label = biz.label or businessId,
    tier = biz.tier or 'standard',
    balance = balance,
    next_due_at = tonumber(row.next_due_at) or 0,
    cycle_amount = tonumber(cycleAmount) or 0,
    breakdown = breakdown or {},
    total_due = total,
    pay_window_open = (windowOpen == true),
    can_pay_cycle = (windowOpen == true) and ((tonumber(cycleAmount) or 0) > 0),
    can_pay_debt = (balance > 0),
  }
end

local function kindKeyForPayment(balance, cycle)
  balance = tonumber(balance) or 0
  cycle = tonumber(cycle) or 0
  if balance > 0 and cycle > 0 then return 'paykind_settle' end
  if balance > 0 and cycle <= 0 then return 'paykind_debt_only' end
  return 'paykind_cycle'
end

-- =========================================================
-- Receipt / Boleta handling
-- =========================================================

local function decodeMeta(meta)
  if type(meta) == 'string' then
    local ok, obj = pcall(json.decode, meta)
    if ok then return obj end
  end
  if type(meta) == 'table' then return meta end
  return {}
end

local function getReceiptIdFromMetadata(metadata)
  if type(metadata) ~= 'table' then return nil end
  return metadata[RECEIPT_META_KEY] or metadata[RECEIPT_META_KEY:upper()] or metadata.receiptId or metadata.receipt_id
end

local function fetchPaymentById(id)
  local rows = MySQL.query.await('SELECT * FROM lbi_payments WHERE id = ? LIMIT 1', { tonumber(id) }) or {}
  return rows[1]
end

local function fetchLatestPaymentByPayer(payerIdentifier)
  local rows = MySQL.query.await('SELECT * FROM lbi_payments WHERE payer_identifier = ? ORDER BY id DESC LIMIT 1', { payerIdentifier }) or {}
  return rows[1]
end

local function openReceiptForPlayer(src, paymentRow, missingId)
  if not paymentRow then
    Bridge.Notify(src, L('receipt_not_found', 'Receipt not found.'), 'error')
    return
  end

  local meta = decodeMeta(paymentRow.meta)
  local biz = getBusiness(paymentRow.business_id)

  local receipt = {
    id = paymentRow.id,
    business_id = paymentRow.business_id,
    business_label = (biz and biz.label) or paymentRow.business_id,
    payer_identifier = paymentRow.payer_identifier,
    payer_name = paymentRow.payer_name,
    paid_at = paymentRow.paid_at,
    method = paymentRow.method,
    method_label = tostring(paymentRow.method or 'bank'),
    amount = paymentRow.amount,
    meta = meta,
    breakdown = meta.breakdown
  }

  if missingId then
    Bridge.Notify(src, L('receipt_missing_id', 'Receipt missing ID; showing latest.'), 'inform')
  end

  TriggerClientEvent('lbi:client:openReceipt', src, receipt)
end

local function handleReceiptUse(src, metadata)
  local payerId = Bridge.GetPrimaryIdentifier(src)
  local receiptId = getReceiptIdFromMetadata(metadata)

  if receiptId then
    local payment = fetchPaymentById(receiptId)
    if not payment then
      Bridge.Notify(src, L('receipt_not_found', 'Receipt not found.'), 'error')
      return
    end
    openReceiptForPlayer(src, payment, false)
    return
  end

  local payment = fetchLatestPaymentByPayer(payerId)
  if not payment then
    Bridge.Notify(src, L('receipt_not_found', 'Receipt not found.'), 'error')
    return
  end
  openReceiptForPlayer(src, payment, true)
end

local function registerReceiptItem()
  if Config and Config.Inventory == 'ox_inventory' and GetResourceState('ox_inventory') == 'started' then
    exports.ox_inventory:RegisterUsableItem(RECEIPT_ITEM, function(data)
      local src = data and data.source
      if not src then return end
      local meta = data.metadata or (data.item and data.item.metadata) or (data.item and data.item.info) or {}
      handleReceiptUse(src, meta)
    end)
    dprint('Receipt item registered via ox_inventory')
    return
  end

  if Bridge and Bridge.Inventory and Bridge.Inventory.RegisterUsableItem then
    local ok = Bridge.Inventory.RegisterUsableItem(RECEIPT_ITEM, function(src, item)
      local meta = {}
      if type(item) == 'table' then
        meta = item.metadata or item.info or item.meta or {}
      end
      handleReceiptUse(src, meta)
    end)

    if ok then
      dprint('Receipt item registered via Bridge')
    else
      dprint('Receipt item registration failed (bridge).')
    end
  end
end

-- =========================================================
-- Core: UI events
-- =========================================================

RegisterNetEvent('lbi:server:ui:requestPayables', function()
  local src = source
  if not Bridge.Init() then return end
  if not antiSpamServer(src) then return end

  local ownedPayables = {}

  for businessId, biz in pairs(Config and Config.Businesses or {}) do
    if isOwnerAllowed(src, biz) then
      local row = ensureStateRow(businessId)
      row = (catchUpBusiness(businessId, row)) or row

      if row then
        local tsNow = now()
        local nextDueAt = tonumber(row.next_due_at) or 0
        local windowStart = nextDueAt - payWindowSeconds()
        local windowOpen = (tsNow >= windowStart)
        local balance = tonumber(row.balance) or 0
        local hasDebt = (balance > 0)

        -- Regla B: SOLO mostrar cuando corresponde pagar:
        --  - Si estás dentro de la ventana (próximo vencimiento cercano), o
        --  - Si ya hay deuda acumulada (balance > 0).
        if windowOpen or hasDebt then
          -- Si no está en ventana, mostramos solo deuda (sin incluir el ciclo futuro).
          local entry = buildPayableEntry(businessId, row, windowOpen, windowOpen)
          if entry and (tonumber(entry.total_due) or 0) > 0 then
            ownedPayables[#ownedPayables+1] = entry
          end
        end

        dprint('[payables]', businessId, 'now=', tsNow, 'next_due_at=', nextDueAt, 'windowOpen=', windowOpen, 'balance=', balance)
      end
    end
  end

  table.sort(ownedPayables, function(a, b)
    return tostring(a.label) < tostring(b.label)
  end)

  if #ownedPayables <= 0 then
    TriggerClientEvent('lbi:client:ui:payables', src, false, nil, 'err_no_payables_now')
    return
  end

  TriggerClientEvent('lbi:client:ui:payables', src, true, { businesses = ownedPayables })
end)

RegisterNetEvent('lbi:server:ui:pay', function(businessId)
  local src = source
  if not Bridge.Init() then return end
  if not antiSpamServer(src) then return end

  businessId = tostring(businessId or '')
  if businessId == '' then
    TriggerClientEvent('lbi:client:ui:paid', src, false, 'err_unknown_business')
    return
  end

  local biz = getBusiness(businessId)
  if not biz then
    TriggerClientEvent('lbi:client:ui:paid', src, false, 'err_unknown_business')
    return
  end

  if not isOwnerAllowed(src, biz) then
    TriggerClientEvent('lbi:client:ui:paid', src, false, 'err_not_owner')
    return
  end

  if not nearNpcOk(src) then
    TriggerClientEvent('lbi:client:ui:paid', src, false, 'err_unknown')
    return
  end

  local row = ensureStateRow(businessId)
  row = (catchUpBusiness(businessId, row)) or row
  if not row then
    TriggerClientEvent('lbi:client:ui:paid', src, false, 'err_unknown')
    return
  end

  local tsNow = now()
  local nextDueAt0 = tonumber(row.next_due_at) or 0
  local windowStart = nextDueAt0 - payWindowSeconds()
  local windowOpen = (tsNow >= windowStart)

  local balance = tonumber(row.balance) or 0
  local payCycle = (windowOpen == true)

  -- Regla B: permitir pagar solo si corresponde:
  --  - Dentro de ventana de pago (ciclo vigente), o
  --  - Hay deuda acumulada (balance > 0).
  if (not payCycle) and balance <= 0 then
    TriggerClientEvent('lbi:client:ui:paid', src, false, 'err_no_payables_now')
    return
  end

  local cycleAmount, breakdown = 0, {}
  if payCycle then
    cycleAmount, breakdown = computeCycleAmountAndBreakdown(businessId)
  end

  local totalDue = balance + (tonumber(cycleAmount) or 0)

  dprint('[pay]', businessId, 'windowOpen=', payCycle, 'balance=', balance, 'cycle=', cycleAmount, 'total=', totalDue)

  if totalDue <= 0 then
    TriggerClientEvent('lbi:client:ui:paid', src, false, 'err_no_debt')
    return
  end
  local isTest = Config and Config.TestMode
  local removeMoney = true
  if isTest and Config.Test and Config.Test.DisableMoneyRemoval then
    removeMoney = false
  end

  if removeMoney then
    local bankBal = Bridge.GetBankBalance(src, { businessId = businessId })
    if (tonumber(bankBal) or 0) < totalDue then
      TriggerClientEvent('lbi:client:ui:paid', src, false, 'err_insufficient_funds')
      return
    end

    local ok = Bridge.RemoveBankMoney(src, totalDue, 'lbi-tax-payment', { businessId = businessId })
    if not ok then
      TriggerClientEvent('lbi:client:ui:paid', src, false, 'err_insufficient_funds')
      return
    end
  end

  local payerIdentifier = Bridge.GetPrimaryIdentifier(src)
  local payerName = Bridge.GetPlayerFullName(src)
  local method = 'bank'
  local paidAt = now()

  local meta = {
    business_id = businessId,
    business_label = biz.label or businessId,
    tier = biz.tier or 'standard',
    tier_multiplier = getTierMultiplier(biz),
    total = totalDue,
    debt_paid = balance,
    cycle_amount = cycleAmount,
    breakdown = breakdown,
    pay_cycle = payCycle,
    pay_window_open = payCycle,
    locale = Config and Config.Locale or 'en'
  }

  local paymentId = MySQL.insert.await([[    INSERT INTO lbi_payments
      (business_id, amount, balance_before, balance_after, paid_at, payer_identifier, payer_name, method, meta)
    VALUES
      (?, ?, ?, ?, ?, ?, ?, ?, ?)
  ]], {
    businessId,
    totalDue,
    balance,
    0,
    paidAt,
    payerIdentifier,
    payerName,
    method,
    json.encode(meta)
  })

  local nextDueAt = tonumber(row.next_due_at) or paidAt
  if payCycle then
    nextDueAt = advanceDueAt(nextDueAt, biz.billing, 1)
    -- Solo reseteamos el recordatorio si realmente pagamos el ciclo vigente
    row.reminder_sent_for_due_at = nil
  end

  row.balance = 0
  row.next_due_at = nextDueAt
  row.last_paid_at = paidAt
  row.last_paid_by = payerIdentifier
  row.last_paid_by_name = payerName
  row.last_paid_method = method
  -- Si había mora notificada, al saldar dejamos limpio
  row.overdue_notified_for_due_at = nil

  dbSaveStateRow(businessId, row)

  local gave = false
  if Bridge and Bridge.Inventory and Bridge.Inventory.AddItem then
    gave = Bridge.Inventory.AddItem(src, RECEIPT_ITEM, 1, { [RECEIPT_META_KEY] = paymentId })
  end
  if not gave then
    Bridge.Notify(src, L('receipt_no_space', 'Could not give receipt.'), 'error')
  end

  local kindKey = kindKeyForPayment(balance, cycleAmount)
  sendPaymentWebhook(businessId, totalDue, payerName, payerIdentifier, method, kindKey, biz.tier, nextDueAt, balance, breakdown)

  TriggerClientEvent('lbi:client:ui:paid', src, true, 'ok_paid', { amount = fmtMoney(totalDue) })
end)

-- =========================================================
-- TEST EVENTS (Config.TestMode = true)
-- =========================================================

local function testAllowed(src)
  if not (Config and Config.TestMode) then
    Bridge.Notify(src, 'TestMode disabled.', 'error')
    return false
  end
  if not Bridge.IsAdmin(src) then
    Bridge.Notify(src, 'No permission.', 'error')
    return false
  end
  return true
end

RegisterNetEvent('lbi:server:test:due', function(businessId, seconds)
  local src = source
  if not Bridge.Init() then return end
  if not testAllowed(src) then return end

  businessId = tostring(businessId or '')
  local biz = getBusiness(businessId)
  if not biz then
    Bridge.Notify(src, L('err_unknown_business', 'Invalid business.'), 'error')
    return
  end

  local row = ensureStateRow(businessId)
  local due = now() + (tonumber(seconds) or 60)
  row.next_due_at = due
  row.reminder_sent_for_due_at = nil
  row.overdue_notified_for_due_at = nil
  dbSaveStateRow(businessId, row)

  Bridge.Notify(src, ('[TEST] next_due_at for %s set to %s'):format(businessId, fmtDateTime(due)), 'success')
end)

RegisterNetEvent('lbi:server:test:reminder', function(businessId)
  local src = source
  if not Bridge.Init() then return end
  if not testAllowed(src) then return end

  businessId = tostring(businessId or '')
  local row = ensureStateRow(businessId)
  if not row then return end
  sendReminderWebhook(businessId, row, 'TEST')
  Bridge.Notify(src, ('[TEST] reminder sent for %s'):format(businessId), 'success')
end)

RegisterNetEvent('lbi:server:test:overdue', function(businessId, periods)
  local src = source
  if not Bridge.Init() then return end
  if not testAllowed(src) then return end

  businessId = tostring(businessId or '')
  local biz = getBusiness(businessId)
  if not biz then
    Bridge.Notify(src, L('err_unknown_business', 'Invalid business.'), 'error')
    return
  end

  local row = ensureStateRow(businessId)
  if not row then return end

  periods = tonumber(periods) or 1
  periods = math.max(1, math.min(50, periods))

  local cycleAmount = select(1, computeCycleAmountAndBreakdown(businessId))
  local added = cycleAmount * periods

  row.balance = (tonumber(row.balance) or 0) + added

  local missedDueAt = tonumber(row.next_due_at) or now()
  row.next_due_at = advanceDueAt(missedDueAt, biz.billing, periods)
  row.reminder_sent_for_due_at = nil
  row.overdue_notified_for_due_at = nil
  dbSaveStateRow(businessId, row)

  sendOverdueWebhook(businessId, row, missedDueAt, added, periods)

  Bridge.Notify(src, ('[TEST] overdue simulated for %s (periods=%s, added=%s)'):format(businessId, periods, fmtMoney(added)), 'success')
end)

RegisterNetEvent('lbi:server:test:pay', function(businessId)
  local src = source
  if not Bridge.Init() then return end
  if not testAllowed(src) then return end

  businessId = tostring(businessId or '')
  local biz = getBusiness(businessId)
  if not biz then
    Bridge.Notify(src, L('err_unknown_business', 'Invalid business.'), 'error')
    return
  end

  local row = ensureStateRow(businessId)
  row = (catchUpBusiness(businessId, row)) or row
  if not row then return end

  local cycleAmount, breakdown = computeCycleAmountAndBreakdown(businessId)
  local balance = tonumber(row.balance) or 0
  local totalDue = balance + cycleAmount

  local payerIdentifier = Bridge.GetPrimaryIdentifier(src)
  local payerName = Bridge.GetPlayerFullName(src)
  local method = 'bank'
  local paidAt = now()

  local meta = {
    business_id = businessId,
    business_label = biz.label or businessId,
    tier = biz.tier or 'standard',
    tier_multiplier = getTierMultiplier(biz),
    total = totalDue,
    debt_paid = balance,
    cycle_amount = cycleAmount,
    breakdown = breakdown,
    test = true
  }

  local paymentId = MySQL.insert.await([[    INSERT INTO lbi_payments
      (business_id, amount, balance_before, balance_after, paid_at, payer_identifier, payer_name, method, meta)
    VALUES
      (?, ?, ?, ?, ?, ?, ?, ?, ?)
  ]], {
    businessId, totalDue, balance, 0, paidAt, payerIdentifier, payerName, method, json.encode(meta)
  })

  local nextDueAt = advanceDueAt(tonumber(row.next_due_at) or paidAt, biz.billing, 1)

  row.balance = 0
  row.next_due_at = nextDueAt
  row.last_paid_at = paidAt
  row.last_paid_by = payerIdentifier
  row.last_paid_by_name = payerName
  row.last_paid_method = method
  row.reminder_sent_for_due_at = nil
  row.overdue_notified_for_due_at = nil
  dbSaveStateRow(businessId, row)

  if Bridge and Bridge.Inventory and Bridge.Inventory.AddItem then
    Bridge.Inventory.AddItem(src, RECEIPT_ITEM, 1, { [RECEIPT_META_KEY] = paymentId })
  end

  sendPaymentWebhook(businessId, totalDue, payerName, payerIdentifier, method, kindKeyForPayment(balance, cycleAmount), biz.tier, nextDueAt, balance, breakdown)
  Bridge.Notify(src, ('[TEST] paid %s for %s'):format(fmtMoney(totalDue), businessId), 'success')
end)

-- =========================================================
-- Legacy events (NO-OP; el client patch v2 aún los llama)
-- =========================================================

RegisterNetEvent('lbi:server:requestStatus', function() end)
RegisterNetEvent('lbi:server:payBusiness', function() end)

-- =========================================================
-- Scheduler thread
-- =========================================================

local function schedulerTick()
  if not (Config and Config.Scheduler and Config.Scheduler.Enabled) then return end

  local tsNow = now()

  for businessId, _ in pairs(Config and Config.Businesses or {}) do
    local row = ensureStateRow(businessId)
    if row then
      local updated, missed, added, lastMissedDueAt, prevOverdueNotified = catchUpBusiness(businessId, row)
      row = updated or row

      if missed > 0 and (Config.Scheduler.OverdueNotifyEnabled ~= false) then
        local last = tonumber(lastMissedDueAt) or 0
        if last > 0 and (tonumber(prevOverdueNotified) or 0) ~= last then
          sendOverdueWebhook(businessId, row, lastMissedDueAt, added, missed)
          row.overdue_notified_for_due_at = last
          dbSaveStateRow(businessId, row)
        end
      end

      if (Config.Scheduler.ReminderEnabled ~= false) then
        local due = tonumber(row.next_due_at) or 0
        if due > 0 then
          local s48 = due - reminder48Seconds()
          local s24 = due - reminder24Seconds()
          if s24 <= s48 then s24 = s48 + 1 end

          local stage = tonumber(row.reminder_sent_for_due_at) or 0

          if tsNow >= s48 and tsNow < s24 and stage ~= s48 then
            sendReminderWebhook(businessId, row, '48h')
            row.reminder_sent_for_due_at = s48
            dbSaveStateRow(businessId, row)
          elseif tsNow >= s24 and tsNow < due and stage ~= s24 then
            sendReminderWebhook(businessId, row, '24h')
            row.reminder_sent_for_due_at = s24
            dbSaveStateRow(businessId, row)
          end
        end
      end
    end
  end
end

local function resetStateIfTest()
  if not (Config and Config.TestMode and Config.Test and Config.Test.ResetStateOnStart) then
    return
  end

  local force = tonumber(Config.Test.ForceDueInSeconds) or 60
  local due = now() + force

  for businessId, _ in pairs(Config and Config.Businesses or {}) do
    MySQL.update.await([[      INSERT IGNORE INTO lbi_business_state
        (business_id, next_due_at, balance, last_paid_at, last_paid_by, last_paid_by_name, last_paid_method, reminder_sent_for_due_at, overdue_notified_for_due_at)
      VALUES (?, ?, 0, NULL, NULL, NULL, NULL, NULL, NULL)
      ON DUPLICATE KEY UPDATE
        next_due_at = VALUES(next_due_at),
        balance = 0,
        last_paid_at = NULL,
        last_paid_by = NULL,
        last_paid_by_name = NULL,
        last_paid_method = NULL,
        reminder_sent_for_due_at = NULL,
        overdue_notified_for_due_at = NULL
    ]], { businessId, due })
  end

  dprint('TestMode ResetStateOnStart applied. Due set to', fmtDateTime(due))
end

-- =========================================================
-- Bootstrap
-- =========================================================

CreateThread(function()
  while not Bridge.Init() do
    Wait(500)
  end

  resetStateIfTest()

  for businessId, _ in pairs(Config and Config.Businesses or {}) do
    local row = ensureStateRow(businessId)
    if row then
      dprint('State ok for', businessId, 'next_due_at=', row.next_due_at, 'balance=', row.balance)
    end
  end

  registerReceiptItem()

  CreateThread(function()
    while true do
      schedulerTick()
      Wait(schedulerTickSeconds() * 1000)
    end
  end)
end)

-- Fix: Ensure the invoice details are sent every time the player interacts with the NPC
RegisterNetEvent('lbi:server:ui:requestPayables')
AddEventHandler('lbi:server:ui:requestPayables', function(businessId)
    local player = source
    local playerIdentifier = GetPlayerIdentifier(player, 0)
    local businessData = getBusiness(businessId) -- Retrieving business data

    -- Get the player's current invoice details (including accumulated debt)
    local invoices = GetInvoicesForPlayer(playerIdentifier)

    -- Send the invoice details to the client again every time
    TriggerClientEvent('lbi:client:ui:payables', player, invoices, businessData)
end)

-- Fix: Ensure the invoice details are sent every time the player interacts with the NPC
RegisterNetEvent('lbi:server:ui:requestPayables')
AddEventHandler('lbi:server:ui:requestPayables', function(businessId)
    local player = source
    local playerIdentifier = GetPlayerIdentifier(player, 0)
    local businessData = getBusiness(businessId) -- Retrieving business data

    -- Get the player's current invoice details (including accumulated debt)
    local invoices = GetInvoicesForPlayer(playerIdentifier)

    -- Send the invoice details to the client again every time
    TriggerClientEvent('lbi:client:ui:payables', player, invoices, businessData)
end)

-- Reset and send invoice details when interacting with NPC
RegisterNetEvent('lbi:server:resetInvoice')
AddEventHandler('lbi:server:resetInvoice', function()
    local player = source
    local playerIdentifier = GetPlayerIdentifier(player, 0)
    local invoices = GetInvoicesForPlayer(playerIdentifier)

    -- Send invoice details to the client again
    TriggerClientEvent('lbi:client:ui:payables', player, invoices)
end)
