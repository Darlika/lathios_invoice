-- shared/framework/init.lua
-- Bridge multi-framework (ESX/NewESX/QBCore) + helpers de dinero/banco
Bridge = Bridge or {}

local _inited = false
local _fw = nil  -- "esx" | "qb"
local ESX, QBCore

local function dprint(...)
  if Config and Config.Debug then
    print("^3[LBI]^7", ...)
  end
end

local function getAllPlayerIdentifiers(src)
  local out = {}
  for i=0, GetNumPlayerIdentifiers(src)-1 do
    local id = GetPlayerIdentifier(src, i)
    if id then
      local k = id:match("^(%w+):")
      if k then out[k] = id end
      table.insert(out, id)
    end
  end
  return out
end

function Bridge.DetectFramework()
  if Config.Framework and Config.Framework ~= "auto" then
    if Config.Framework == "qb" then return "qb" end
    if Config.Framework == "esx" or Config.Framework == "newesx" then return "esx" end
  end

  if GetResourceState('qb-core') == 'started' then return "qb" end
  if GetResourceState('es_extended') == 'started' then return "esx" end
  return nil
end

local function initESX()
  if ESX then return true end
  -- NewESX / modern ESX export
  if GetResourceState('es_extended') == 'started' then
    local ok, obj = pcall(function()
      return exports['es_extended']:getSharedObject()
    end)
    if ok and obj then
      ESX = obj
      dprint("ESX loaded via exports['es_extended']:getSharedObject()")
      return true
    end
  end

  -- Legacy event fallback
  local tries = 0
  while not ESX and tries < 50 do
    tries += 1
    TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
    Wait(50)
  end

  if ESX then
    dprint("ESX loaded via TriggerEvent('esx:getSharedObject')")
    return true
  end
  return false
end

local function initQB()
  if QBCore then return true end
  if GetResourceState('qb-core') ~= 'started' then return false end
  local ok, obj = pcall(function()
    return exports['qb-core']:GetCoreObject()
  end)
  if ok and obj then
    QBCore = obj
    dprint("QBCore loaded via exports['qb-core']:GetCoreObject()")
    return true
  end
  return false
end

function Bridge.Init()
  if _inited then return true end
  _fw = Bridge.DetectFramework()
  if not _fw then
    dprint("No framework detected yet.")
    return false
  end

  if _fw == "esx" then
    _inited = initESX()
  elseif _fw == "qb" then
    _inited = initQB()
  end

  if _inited then
    dprint("Bridge initialized. fw=", _fw)
  else
    dprint("Bridge init failed for fw=", _fw)
  end
  return _inited
end

function Bridge.GetFramework()
  if not _inited then Bridge.Init() end
  return _fw
end

-- =========================
-- Server-side helpers
-- =========================
if IsDuplicityVersion() then
  function Bridge.GetPlayer(src)
    if not _inited then Bridge.Init() end
    if _fw == "esx" and ESX then
      return ESX.GetPlayerFromId(src)
    elseif _fw == "qb" and QBCore then
      return QBCore.Functions.GetPlayer(src)
    end
    return nil
  end

  function Bridge.GetIdentifierMap(src)
    return getAllPlayerIdentifiers(src)
  end

  function Bridge.GetPrimaryIdentifier(src)
    -- Prefer license if available, else citizenid (qb), else first identifier
    local ids = Bridge.GetIdentifierMap(src)
    if ids.license then return ids.license end
    local player = Bridge.GetPlayer(src)
    if _fw == "qb" and player and player.PlayerData and player.PlayerData.citizenid then
      return "citizenid:" .. player.PlayerData.citizenid
    end
    return ids[1]
  end

  function Bridge.GetPlayerFullName(src)
    local player = Bridge.GetPlayer(src)
    if not player then return GetPlayerName(src) or ("Player "..tostring(src)) end
    if _fw == "esx" then
      -- xPlayer.getName() suele traer nombre y apellido
      if player.getName then
        return player.getName()
      end
      return GetPlayerName(src) or ("Player "..tostring(src))
    else
      local ci = player.PlayerData and player.PlayerData.charinfo or nil
      if ci and (ci.firstname or ci.lastname) then
        return (ci.firstname or "") .. " " .. (ci.lastname or "")
      end
      return GetPlayerName(src) or ("Player "..tostring(src))
    end
  end

  function Bridge.MatchesOwner(src, ownerIdentifiers)
    if type(ownerIdentifiers) ~= "table" then return false end
    local ids = Bridge.GetIdentifierMap(src)
    local primary = Bridge.GetPrimaryIdentifier(src)

    for _, allowed in ipairs(ownerIdentifiers) do
      if allowed == primary then return true end
      -- Match against any identifier type, e.g. license:, steam:, discord:
      local k = tostring(allowed):match("^(%w+):")
      if k and ids[k] and ids[k] == allowed then return true end
      -- Also match if allowed equals any raw identifier
      if ids and type(ids) == "table" then
        for _, anyId in ipairs(ids) do
          if anyId == allowed then return true end
        end
      end
    end
    return false
  end

  -- -------- Money / Bank --------
-- NOTE:
--   Config.Bank controls which banking system is used.
--   Supported: 'framework' | 'okokbanking' | 'wasabi_bank'/'wasabi_banking' | 'qb-banking' | 'esx_addonaccount'
local function normalizeBankMode()
  local mode = (Config and Config.Bank) or "framework"
  mode = tostring(mode):lower()
  if mode == "wasabi_bank" then mode = "wasabi_banking" end
  return mode
end

local function getPlayerBankAccountId(src)
  -- okokBanking uses "citizenid" (QB) or identifier (ESX) as account identifier in most setups
  local player = Bridge.GetPlayer(src)
  if _fw == "qb" and player and player.PlayerData and player.PlayerData.citizenid then
    return player.PlayerData.citizenid
  end
  if _fw == "esx" and player then
    if player.identifier then return player.identifier end
    if player.getIdentifier then return player.getIdentifier() end
  end
  return Bridge.GetPrimaryIdentifier(src) or tostring(src)
end

local function frameworkGetBank(src)
  local player = Bridge.GetPlayer(src)
  if not player then return 0 end
  if _fw == "esx" then
    local acc = player.getAccount and player.getAccount('bank')
    return acc and acc.money or 0
  else
    return player.Functions.GetMoney('bank') or 0
  end
end

local function frameworkRemoveBank(src, amount, reason)
  local player = Bridge.GetPlayer(src)
  if not player then return false end
  amount = tonumber(amount) or 0
  if amount <= 0 then return true end
  if _fw == "esx" then
    player.removeAccountMoney('bank', amount)
    return true
  else
    return player.Functions.RemoveMoney('bank', amount, reason or 'lbi-tax-payment')
  end
end

local function okokGetBank(src)
  if GetResourceState('okokBanking') ~= 'started' then return nil end
  local accountId = getPlayerBankAccountId(src)
  local ok, res = pcall(function()
    return exports['okokBanking']:GetAccount(accountId)
  end)
  if not ok then return nil end
  if type(res) == "table" then
    return tonumber(res.money) or tonumber(res.balance) or 0
  end
  return tonumber(res) or 0
end

local function okokRemoveBank(src, amount)
  if GetResourceState('okokBanking') ~= 'started' then return false end
  local accountId = getPlayerBankAccountId(src)
  local ok, res = pcall(function()
    return exports['okokBanking']:RemoveMoney(accountId, tonumber(amount) or 0)
  end)
  if not ok then return false end
  -- Many okok exports return nothing on success; treat non-false as ok
  return res ~= false
end

local function wasabiGetBank(src)
  if GetResourceState('wasabi_banking') ~= 'started' then return nil end
  local accountId = tostring(src)
  local ok, res = pcall(function()
    return exports['wasabi_banking']:GetAccountBalance(accountId, 'bank')
  end)
  if not ok or res == false or res == nil then return nil end
  return tonumber(res) or 0
end

local function wasabiRemoveBank(src, amount, reason)
  if GetResourceState('wasabi_banking') ~= 'started' then return false end
  local accountId = tostring(src)
  local ok, res = pcall(function()
    -- RemoveMoney(type, accountID, amount, source?)
    return exports['wasabi_banking']:RemoveMoney('bank', accountId, tonumber(amount) or 0, src)
  end)
  if not ok then return false end
  return res ~= false
end

local function esxAddonGetSharedAccountMoney(accountName)
  if GetResourceState('esx_addonaccount') ~= 'started' then return nil end
  local p = promise.new()
  TriggerEvent('esx_addonaccount:getSharedAccount', accountName, function(account)
    p:resolve(account)
  end)
  local account = Citizen.Await(p)
  if account and account.money ~= nil then
    return tonumber(account.money) or 0
  end
  return 0
end

local function esxAddonRemoveSharedAccountMoney(accountName, amount)
  if GetResourceState('esx_addonaccount') ~= 'started' then return false end
  local p = promise.new()
  TriggerEvent('esx_addonaccount:getSharedAccount', accountName, function(account)
    if account and account.removeMoney then
      account.removeMoney(tonumber(amount) or 0)
      p:resolve(true)
    else
      p:resolve(false)
    end
  end)
  return Citizen.Await(p) == true
end

function Bridge.GetBankBalance(src, ctx)
  local mode = normalizeBankMode()
  if mode == "framework" or mode == "qb-banking" then
    return frameworkGetBank(src)
  end

  if mode == "okokbanking" then
    return okokGetBank(src) or frameworkGetBank(src)
  end

  if mode == "wasabi_banking" then
    return wasabiGetBank(src) or frameworkGetBank(src)
  end

  if mode == "esx_addonaccount" and _fw == "esx" then
    local accountName = nil
    if type(ctx) == "table" then
      accountName = ctx.society or ctx.account or ctx.societyName
      if not accountName and ctx.businessId then
        accountName = "society_" .. tostring(ctx.businessId)
      end
    end
    if accountName then
      return esxAddonGetSharedAccountMoney(accountName) or 0
    end
    return frameworkGetBank(src)
  end

  -- Unknown mode -> fallback
  return frameworkGetBank(src)
end

function Bridge.RemoveBankMoney(src, amount, reason, ctx)
  local mode = normalizeBankMode()

  if mode == "framework" or mode == "qb-banking" then
    return frameworkRemoveBank(src, amount, reason)
  end

  if mode == "okokbanking" then
    local ok = okokRemoveBank(src, amount)
    if ok then return true end
    return frameworkRemoveBank(src, amount, reason)
  end

  if mode == "wasabi_banking" then
    local ok = wasabiRemoveBank(src, amount, reason)
    if ok then return true end
    return frameworkRemoveBank(src, amount, reason)
  end

  if mode == "esx_addonaccount" and _fw == "esx" then
    local accountName = nil
    if type(ctx) == "table" then
      accountName = ctx.society or ctx.account or ctx.societyName
      if not accountName and ctx.businessId then
        accountName = "society_" .. tostring(ctx.businessId)
      end
    end
    if accountName then
      return esxAddonRemoveSharedAccountMoney(accountName, amount)
    end
    return frameworkRemoveBank(src, amount, reason)
  end

  return frameworkRemoveBank(src, amount, reason)
end


  -- -------- Inventory (items/receipts) --------
  -- NOTE: This is a light bridge for adding items + registering usable items across inventories.
  Bridge.Inventory = Bridge.Inventory or {}

  local function invMode()
    return (Config and Config.Inventory) or nil
  end

  function Bridge.Inventory.AddItem(src, itemName, count, metadata)
    count = tonumber(count) or 1
    local mode = invMode()

    if mode == "ox_inventory" and GetResourceState("ox_inventory") == "started" then
      return exports.ox_inventory:AddItem(src, itemName, count, metadata)
    end

    if mode == "qs-inventory" and GetResourceState("qs-inventory") == "started" then
      -- QS stores metadata in item.info
      return exports['qs-inventory']:AddItem(src, itemName, count, false, metadata)
    end

    if mode == "origen_inventory" and GetResourceState("origen_inventory") == "started" then
      return exports.origen_inventory:addItem(src, itemName, count, metadata)
    end

    if mode == "qb" and _fw == "qb" and QBCore then
      local player = Bridge.GetPlayer(src)
      if player and player.Functions and player.Functions.AddItem then
        return player.Functions.AddItem(itemName, count, false, metadata)
      end
    end

    -- Fallbacks: framework inventory (limited metadata support)
    local player = Bridge.GetPlayer(src)
    if _fw == "esx" and player and player.addInventoryItem then
      player.addInventoryItem(itemName, count)
      return true
    end
    if _fw == "qb" and player and player.Functions and player.Functions.AddItem then
      return player.Functions.AddItem(itemName, count, false, metadata)
    end

    return false
  end

  function Bridge.Inventory.RegisterUsableItem(itemName, cb)
    local mode = invMode()

    if mode == "qs-inventory" and GetResourceState("qs-inventory") == "started" then
      if exports['qs-inventory'] and exports['qs-inventory'].CreateUsableItem then
        exports['qs-inventory']:CreateUsableItem(itemName, cb)
        return true
      end
      return false
    end

    if mode == "origen_inventory" and GetResourceState("origen_inventory") == "started" then
      if exports.origen_inventory and exports.origen_inventory.CreateUseableItem then
        exports.origen_inventory:CreateUseableItem(itemName, cb)
        return true
      end
      return false
    end

    if mode == "qb" and _fw == "qb" and QBCore and QBCore.Functions and QBCore.Functions.CreateUseableItem then
      QBCore.Functions.CreateUseableItem(itemName, cb)
      return true
    end

    -- ox_inventory doesn't use a register function here; handle via 'ox_inventory:usedItem' in server code.
    -- ESX fallback (no item metadata)
    if _fw == "esx" and ESX and ESX.RegisterUsableItem then
      ESX.RegisterUsableItem(itemName, function(src)
        cb(src, nil)
      end)
      return true
    end

    return false
  end

  function Bridge.Notify(src, msg, msgType, duration)
    msgType = msgType or "inform"
    duration = duration or 4500
    if _fw == "qb" and QBCore then
      TriggerClientEvent('QBCore:Notify', src, msg, msgType, duration)
      return
    end
    -- ESX notify fallback
    TriggerClientEvent('esx:showNotification', src, msg)
  
  end


  -- -------- Permissions --------
  -- QBCore: usa QBCore.Functions.HasPermission(src, 'admin'/'god')
  function Bridge.HasPermission(src, perm)
    if not _inited then Bridge.Init() end
    if _fw == "qb" and QBCore and QBCore.Functions and QBCore.Functions.HasPermission then
      return QBCore.Functions.HasPermission(src, perm)
    end
    return false
  end

  function Bridge.IsAdmin(src)
    if src == 0 then return true end

    -- Prefer framework-native permissions
    if _fw == "qb" then
      if Bridge.HasPermission(src, "god") or Bridge.HasPermission(src, "admin") then
        return true
      end
    elseif _fw == "esx" then
      local player = Bridge.GetPlayer(src)
      if player and player.getGroup then
        local g = player.getGroup()
        if g == "admin" or g == "superadmin" then
          return true
        end
      end
    end

    -- Fallback ACE permission (optional)
    return IsPlayerAceAllowed(src, "lbi.admin")
  end
else
  -- =========================
  -- Client-side helpers
  -- =========================
  function Bridge.Notify(msg, msgType, duration)
    msgType = msgType or "inform"
    duration = duration or 4500
    local fw = Bridge.GetFramework()
    if fw == "qb" then
      TriggerEvent('QBCore:Notify', msg, msgType, duration)
      return
    end
    TriggerEvent('esx:showNotification', msg)
  end
end
